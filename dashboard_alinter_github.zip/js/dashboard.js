
fetch('data/Dashboard definitivo.xlsx')
 .then(r=>r.arrayBuffer())
 .then(b=>{
  const wb=XLSX.read(b,{type:'array'});
  const sh=XLSX.utils.sheet_to_json(wb.Sheets['Cacitos_Control Producción'],{header:1});
  let real=0,obj=0,limp=0,lab=[],r=[],o=[];
  sh.forEach(x=>{if(typeof x[0]==='string'&&x[0].startsWith('Semana')){lab.push(x[0]);o.push(+x[2]);r.push(+x[3]);obj+=+x[2];real+=+x[3];limp+=+x[5];}});
  kpiReal.textContent=real.toLocaleString();
  kpiObjetivo.textContent=obj.toLocaleString();
  kpiCumplimiento.textContent=((real/obj)*100).toFixed(1)+'%';
  kpiLimpieza.textContent=limp;
  new Chart(chartProduccion,{type:'bar',data:{labels:lab,datasets:[{label:'Real',data:r},{label:'Objetivo',data:o}]}});
  const cov=XLSX.utils.sheet_to_json(wb.Sheets['Cobertura HDO']);
  cov.forEach(c=>{if(!c['Descripción producto'])return;const tr=document.createElement('tr');const d=c['cobertura en días'];tr.className=d<10?'low':d<20?'medium':'high';tr.innerHTML=`<td>${c['Descripción producto']}</td><td>${c['Stock con Ventas Hasta 16/03']}</td><td>${c['Previs Totales HDO hasta el 28/03']}</td><td>${Number(d).toFixed(1)}</td>`;tablaCoberturas.appendChild(tr);});
  update.textContent='Actualizado: '+new Date().toLocaleString();
 });
